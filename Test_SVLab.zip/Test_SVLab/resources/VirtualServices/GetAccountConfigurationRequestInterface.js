import * as sv from "sv-vsl";


export class GetAccountConfigurationRequestInterface extends sv.RestServiceInterface {

    constructor() {
        super();
        this.importExternal("./GetAccountConfigurationRequestInterfaceSwagger.json");
    }

}